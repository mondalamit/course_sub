Requested Course Substitions for Amit Mondal

******
Legend
******

Syllabus included : X
Course Description included: Y

------

XY / Transfer Course Number / Orig. Course Number / Orig. Course Name -> KSU Course Name (KSU Course Number) [Original/Requested Credit hours]

XY MATH 1T00 / 1016-271 Calculus A -> Calculus I (MATH 1190) [3/4]
XY MATH 1T01 / MATH 172 Calculus B -> Calculus I and Calculus II (MATH 1190 / MATH 2202) [3/4]
XY MATH 1T02 / MATH 173 Calculus C -> Calculus II (MATH 2202) [3/4]
 Y STAT 1107 / MATH 251 Probability and Statistics I -> Probability and Inference (MATH 3332) [3/3]

(Course details are in a website for the two below. Link at the top of each syllabus.)
X  CS 1T00 / 4003-241 Problem-Based Intro CS -> Programming Principles I (CSE 1321/L) [3/4]
X  CS 1T01 / CSCI 142 Computer Science II -> Programming Principles II (CSE 1322/L) [4/4]

X  IS 3T00 / CSCI 320 Principles of Data Management -> Introduction to Database Systems (CS3410) [3/3]